import SnowBored from "../components/SnowBored"

export default function Home() {
  return (
    <main>
      <SnowBored />
    </main>
  )
}

